function dest_pts_nx2 = applyHomography(H_3x3, src_pts_nx2)

%add 1 to end of source points
src_pts_nx3 = [src_pts_nx2 ones(size(src_pts_nx2,1),1)];
dest_pts_3xn = (H_3x3*src_pts_nx3');
dest_pts_nx3 = dest_pts_3xn';

%back to 2D, divide the other rows by last column
dest_pts_nx2 = dest_pts_nx3(:,1:2)./dest_pts_nx3(:,3);

end
