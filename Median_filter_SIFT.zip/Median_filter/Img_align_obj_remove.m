folder = 'C:\Users\Dimuth Panditharatne\Desktop\Spring 2023\CS 766\MATLAB\ams\';
% folder = 'C:\Users\Dimuth Panditharatne\Desktop\Spring 2023\CS 766\MATLAB\dam-shaky\';
filelist = dir([folder '*.jpg']);
% Load the first image in the sequence
refFrame = imread([folder filelist(1).name]);

% Creating buffer for stabilized images
numFrames = 4;
stabilizedBuffer = zeros([size(refFrame), numFrames]);
stabilizedBuffer(:, :, :, 1) = double(refFrame);

% Sliding window size
windowSize = 3;

% Loop through the rest of the images
for i = 2:length(filelist)

    currentFrame = imread([folder filelist(i).name]);
    disp(i)

    % Stabilize the current frame using SIFTMatches
    [xs, xd] = genSIFTMatches(refFrame, currentFrame, 'VLFeat');
    [inliers_id, H_3x3] = runRANSAC(xs, xd, 250, 2);

    % projective2d object from the homography matrix
    tform = projective2d(H_3x3');

    % Applying the homography to the current frame
    stabilizedFrame = imwarp(currentFrame, tform, 'OutputView', imref2d(size(refFrame)));

    % Update the stabilized buffer with the stabilized frame
    stabilizedBuffer(:, :, :, mod(i-1, numFrames) + 1) = double(stabilizedFrame);

    % Update the background model using the median filter
    % Using sliding window approach
    startFrame = max(1, i - windowSize);
    endFrame = min(length(filelist), i + windowSize);
    slidingWindowBuffer = stabilizedBuffer(:, :, :, mod(startFrame-1:endFrame-1, numFrames) + 1);
    bgModel = median(slidingWindowBuffer, 4);
end

% Compute the difference between the current frame and the background model
diffImage = imabsdiff(refFrame, uint8(bgModel));

% Convert the difference image to grayscale and apply a threshold
diffImage = rgb2gray(diffImage);
threshold = 30;
foreground = diffImage > threshold;

% Apply morphological operations to the binary foreground image
se = strel('disk', 2);
foreground = imopen(foreground, se);
foreground = imclose(foreground, se);
foreground = imfill(foreground, 'holes');

% Display the final background and foreground images
subplot(1, 2, 1), imshow(uint8(bgModel)), title('Background');
subplot(1, 2, 2), imshow(foreground), title('Foreground');