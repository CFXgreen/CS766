function H_3x3 = computeHomography(src_pts_nx2, dest_pts_nx2)
% src_pts_nx2 and dest_pts_nx2 are the coordinates of corresponding points 
% of the two images, respectively. src_pts_nx2 and dest_pts_nx2 
% are nx2 matrices, where the first column contains
% the x coodinates and the second column contains the y coordinates.
%
% H, a 3x3 matrix, is the estimated homography that 
% transforms src_pts_nx2 to dest_pts_nx2. 

n = size(src_pts_nx2,1);
%create A matrix (nx2,9)
A = zeros(n*2,9);

% x1 = src_pts_nx2(1,1);
% y1 = src_pts_nx2(2,2);

for i = 1:n
    x_src = src_pts_nx2(i,1);
    y_src = src_pts_nx2(i,2);
    x_dest = dest_pts_nx2(i,1);
    y_dest = dest_pts_nx2(i,2);
    %A h = 0 represent as flattened
    A(i*2-1,:) = [x_src y_src 1 zeros(1,3) -x_src*x_dest -y_src*x_dest -x_dest]; %A(1,3...,:)
    A(i*2,:) = [zeros(1,3) x_src y_src 1 -x_src*y_dest -y_src*y_dest -y_dest]; %A(2,4...,:)
end

[H,~] = eig(A'*A);
%reshap H to 3x3
H_3x3 = reshape(H(:,1),3,3)';
end