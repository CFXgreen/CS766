function [inliers_id, H] = runRANSAC(Xs, Xd, ransac_n, eps)
% xs and xd are the centers of matched frames
% xs and xd are nx2 matrices, where the first column contains the x
% coordinates and the second column contains the y coordinates

% ransac_n = 50; % Max number of iterations
% ransac_eps = 0.8; %Acceptable alignment error 

num_inliers = 0;
% n = size(Xs,1);
for iter = 1:ransac_n
    inliers = 0;
    inlier_ids_arr = [];
    %use 4 random source points and get the destination points
    rand = randi([1 size(Xs,1)],1,4);
    H_dest = computeHomography(Xs(rand,:), Xd(rand,:));  %find homography
    for i = 1:size(Xs,1)
        % apply the homography to find the destination point
        Hm = applyHomography(H_dest, Xs(i,:));
        err = norm(Hm - Xd(i, :));  %euclidean distance for error

        if err <= eps
            inliers = inliers+1;
            inlier_ids_arr = [inlier_ids_arr; i];
        end
    end
    % collect the max inliers for each RANSAC iterations
    if inliers > num_inliers
        num_inliers = inliers;
        H = H_dest;
        inliers_id = inlier_ids_arr;
    end
end
end



