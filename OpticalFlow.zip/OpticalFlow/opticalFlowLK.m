function [flow] = opticalFlowLK(prevGray, currGray, windowSize)
    [h, w] = size(prevGray);
    [Ix, Iy] = gradient(double(prevGray));
    It = double(currGray) - double(prevGray);
    
    halfWindowSize = floor(windowSize / 2);
    flow = zeros(h, w, 2);
    
    for y = halfWindowSize + 1 : h - halfWindowSize
        for x = halfWindowSize + 1 : w - halfWindowSize
            Ix_window = Ix(y - halfWindowSize : y + halfWindowSize, x - halfWindowSize : x + halfWindowSize);
            Iy_window = Iy(y - halfWindowSize : y + halfWindowSize, x - halfWindowSize : x + halfWindowSize);
            It_window = It(y - halfWindowSize : y + halfWindowSize, x - halfWindowSize : x + halfWindowSize);
            
            A = [Ix_window(:), Iy_window(:)];
            b = -It_window(:);
            v = pinv(A' * A) * A' * b;
            
            flow(y, x, :) = v';
        end
    end
end