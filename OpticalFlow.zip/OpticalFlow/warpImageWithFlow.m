function [warpedImage] = warpImageWithFlow(I, flow)
    [h, w, ~] = size(I);
    [gridX, gridY] = meshgrid(1:w, 1:h);
    flowX = gridX + flow(:,:,1);
    flowY = gridY + flow(:,:,2);
    
    warpedImage = zeros(size(I), 'like', I);
    for c = 1:size(I, 3)
        warpedImage(:,:,c) = interp2(double(I(:,:,c)), flowX, flowY, 'linear', 0);
    end
end