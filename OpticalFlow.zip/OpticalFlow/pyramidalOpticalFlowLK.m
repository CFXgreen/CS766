% function [flow] = pyramidalOpticalFlowLK(prevGray, currGray, windowSize, numLevels)
%     flow = zeros(size(prevGray, 1), size(prevGray, 2), 2);
%     
%     % Create image pyramids
%     prevPyramid = cell(1, numLevels);
%     currPyramid = cell(1, numLevels);
%     prevPyramid{1} = prevGray;
%     currPyramid{1} = currGray;
%     
%     for i = 2:numLevels
%         prevPyramid{i} = impyramid(prevPyramid{i-1}, 'reduce');
%         currPyramid{i} = impyramid(currPyramid{i-1}, 'reduce');
%     end
%     
%     % Iterate through the pyramid levels, starting from the coarsest resolution
%     for level = numLevels:-1:1
%         flow = 2 * imresize(flow, size(prevPyramid{level}));
%         flow = flow + opticalFlowLK(prevPyramid{level}, currPyramid{level}, windowSize);
%     end
% end
function [flow] = pyramidalOpticalFlowLK(prevGray, currGray, windowSize, numLevels, numIterations)
    flow = zeros(size(prevGray, 1), size(prevGray, 2), 2);
    
    % Create image pyramids
    prevPyramid = cell(1, numLevels);
    currPyramid = cell(1, numLevels);
    prevPyramid{1} = prevGray;
    currPyramid{1} = currGray;
    
    for i = 2:numLevels
        prevPyramid{i} = impyramid(prevPyramid{i-1}, 'reduce');
        currPyramid{i} = impyramid(currPyramid{i-1}, 'reduce');
    end
    
    % Iterate through the pyramid levels, starting from the coarsest resolution
    for level = numLevels:-1:1
        flow = 2 * imresize(flow, size(prevPyramid{level}));
        for iteration = 1:numIterations
            warpedCurrGray = warpImageWithFlow(currPyramid{level}, flow);
            flow = flow + opticalFlowLK(prevPyramid{level}, warpedCurrGray, windowSize);
        end
    end
end