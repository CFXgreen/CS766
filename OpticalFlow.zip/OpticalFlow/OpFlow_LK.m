% Load the first image in the sequence
folder = 'C:\Users\Dimuth Panditharatne\Desktop\Spring 2023\CS 766\MATLAB\dam-shaky\';
filelist = dir([folder '*.jpg']);
refFrame = imread([folder filelist(1).name]);

% Initialize the buffer for stabilized images
numFrames = 3;
stabilizedBuffer = zeros([size(refFrame), numFrames]);
stabilizedBuffer(:, :, :, 1) = double(refFrame);

% Loop through the rest of the images
for i = 2:length(filelist)
    % Read the next image in the sequence
    currentFrame = imread([folder filelist(i).name]);
    disp(i)
    
    % Compute the optical flow with enhancements
    prevGray = histeq(rgb2gray(refFrame));
    currGray = histeq(rgb2gray(currentFrame));
    flow = pyramidalOpticalFlowLK(prevGray, currGray, 15, 4,3);
    flow = imgaussfilt(flow, 1);
    
    % Warp the current frame using the estimated flow
    stabilizedFrame = warpImageWithFlow(currentFrame, flow);
    
    % Update the stabilized buffer with the stabilized frame
    stabilizedBuffer(:, :, :, mod(i-1, numFrames) + 1) = double(stabilizedFrame);

    % Update the background model using the median filter
    bgModel = median(stabilizedBuffer, 4);
end

% Post-process the background model
bgModel = uint8(bgModel);
sharpenedBgModel = imsharpen(bgModel, 'Radius', 2, 'Amount', 1);

% Compute the difference between the current frame and the background model
diffImage = imabsdiff(refFrame, sharpenedBgModel);

% Convert the difference image to grayscale and apply a threshold
diffImage = rgb2gray(diffImage);
threshold = 20;
foreground = diffImage > threshold;

% Apply morphological operations to the binary foreground image
se = strel('disk', 2);
foreground = imopen(foreground, se);
foreground = imclose(foreground, se);
foreground = imfill(foreground, 'holes');

% Display the final background and foreground images
subplot(1, 2, 1), imshow(sharpenedBgModel), title('Background');
subplot(1, 2, 2), imshow(foreground), title('Foreground');
imwrite(foreground, 'foreground_ams_shaky_OPLK.png');
imwrite(uint8(bgModel), 'background_ams_shaky_OPLK.png');