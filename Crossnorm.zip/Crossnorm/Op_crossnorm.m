% Load the first image in the sequence
% folder = 'C:\Users\Dimuth Panditharatne\Desktop\Spring 2023\CS 766\MATLAB\dam-shaky\';
% folder = 'C:\Users\Dimuth Panditharatne\Desktop\Spring 2023\CS 766\MATLAB\ams-shaky-1\';
folder = 'C:\Users\Dimuth Panditharatne\Desktop\Spring 2023\CS 766\MATLAB\rembrant-shaky\';
filelist = dir([folder '*.jpg']);
refFrame = imread([folder filelist(1).name]);

% Initialize the buffer for stabilized images
% numFrames = 6; %3 optimal for dam-shaky
numFrames = 3; %3 optimal for dam-shaky
stabilizedBuffer = zeros([size(refFrame), numFrames]);
stabilizedBuffer(:, :, :, 1) = double(refFrame);

for i = 2:length(filelist)
    % Read the next image in the sequence
    currentFrame = imread([folder filelist(i).name]);
    disp(i)
    
    % Estimate the shift using cross-correlation
    refGray = rgb2gray(refFrame);
    currGray = rgb2gray(currentFrame);
    c = normxcorr2(refGray, currGray);
    [~, maxIndex] = max(abs(c(:)));
    [ypeak, xpeak] = ind2sub(size(c), maxIndex);
    shift = [ypeak - size(refGray, 1), xpeak - size(refGray, 2)];
    
    % Shift the current frame to align it with the reference frame
    stabilizedFrame = imtranslate(currentFrame, -shift);
    
    % Update the stabilized buffer with the stabilized frame
    stabilizedBuffer(:, :, :, mod(i-1, numFrames) + 1) = double(stabilizedFrame);

    % Update the background model using the median filter
    bgModel = median(stabilizedBuffer, 4);
end

% Compute the difference between the current frame and the background model
diffImage = imabsdiff(refFrame, uint8(bgModel));

% Convert the difference image to grayscale and apply a threshold
diffImage = rgb2gray(diffImage);
threshold = 20; %default 30, for dam-shaky 15-20
foreground = diffImage > threshold;

% Applying morphological operations to the binary foreground image
se = strel('disk', 2);
foreground = imopen(foreground, se);
foreground = imclose(foreground, se);
foreground = imfill(foreground, 'holes');

% Display results
subplot(1, 2, 1), imshow(uint8(bgModel)), title('Background');
subplot(1, 2, 2), imshow(foreground), title('Foreground');

imwrite(foreground, 'foreground_ams_shaky_crossnorm.png');
imwrite(uint8(bgModel), 'background_ams_shaky_crossnorm.png');